package com.android.tests.flavors.group1;

public class SomeClass {
    public static String getString() {
        return "f1";
    }
}