package com.android.tests.flavors;

public class CustomizedClass {
    public static String getString() {
        return "f2-fb-release";
    }
}