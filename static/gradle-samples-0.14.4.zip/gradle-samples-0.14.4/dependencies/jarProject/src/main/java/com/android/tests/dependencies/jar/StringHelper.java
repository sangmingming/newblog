package com.android.tests.dependencies.jar;

public class StringHelper {

    public static String getString(String str) {
        return str + "-helper";
    }
}