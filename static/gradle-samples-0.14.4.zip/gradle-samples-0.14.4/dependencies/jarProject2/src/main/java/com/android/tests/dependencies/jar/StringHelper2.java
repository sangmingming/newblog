package com.android.tests.dependencies.jar;

public class StringHelper2 {

    public static String getString2(String str) {
        return str + "-helper";
    }
}