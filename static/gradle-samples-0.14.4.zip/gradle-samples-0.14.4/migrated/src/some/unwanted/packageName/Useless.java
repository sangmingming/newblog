package some.unwanted.packageName;

public class Useless {
    public static final void doNothing() {
    }
}