package com.android.tests.extractannotations;

public class Constants {
    public static final int CONSTANT_1 = 1;
    public static final int CONSTANT_2 = CONSTANT_1 + 1;
    public static final int CONSTANT_3 = CONSTANT_2 + 1;
    public static final int FLAG_VALUE_1 = 0x1;
    public static final int FLAG_VALUE_2 = 0x2;
}
